
def buildTestSet(path):
	inputFile = open(path, 'r')
	binList = []
	paramList = []
	testNameList = []
	for line in inputFile.readlines():
		if '#' in line or len(line.split()) < 3 : continue

		line = line.split()
		name = line[0]
		bin = line[1]
		params = ' --'.join(line[2:])
		binList.append(bin)
		testNameList.append(name)
		if params:
			paramList.append(' --'+params)
		else:
			paramList.append(' ')
	inputFile.close()
	
	return [testNameList, binList, paramList]


# LISTA COM AS ESTRUTURAS DE GOP A SEREM TESTADAS
gopStructureList = ['encoder_lowdelay_main']

# LISTA COM AS SEQUENCIAS E O NUMERO DE FRAMES A SEREM CODIFICADOS
sequenceList = [['BQSquare', 64],['BlowingBubbles', 64], \
				['Traffic', 64],['PeopleOnStreet', 64], \
				['BasketballDrive', 64],['ParkScene', 64], \
				['RaceHorsesC', 64],['BQMall', 64], \
				['ChinaSpeed', 64],['BasketballDrillText', 64], \
				['Johnny', 64],  ['FourPeople',64]]

# LISTA COM OS VALORES DE QP
qpList = ['22', '27', '32', '37']

# PATH RAIZ DAS CFGS DO HM
cfgPath = '../cfg'

# PATH RAIZ DAS CFGS DE SEQUENCIAS (ORIGINALMENTE EH ../cfg/per-sequence)
sequencePath = '/home/grellert/hm-cfgs/cropped'

# PATH DO DIRETORIO QUE VAI CONTER OS ARQUIVOS TEMPORARIOS DE SAIDA DOS TESTES
# ESSA PASTA PRECISA EXISTIR E PRECISA CONTER SOMENTE MINUSCULAS NO PATH!!
hmOutputPath = './hmoutput'  

# PATH PARA O BINARIO REFERENCIA DO HM. NORMALMENTE O PATH PARA O BINARIO DO HM SEM MODIFICACOES
pathToRefBin = '../bin/TAppEncoderStatic_Ref'

# PARAMETROS OPCIONAIS PARA INCLUIR NA CODIFICACAO DA REFERENCIA
optParamsRef = ''
#optParamsRef = ' --SearchRange=32 --AMP=0'

# O ARQUIVO Tests.inp VAI CONTER TODOS OS TESTES QUE SERAO COMPARADOS A REFERENCIA
[testNameList, pathToTestBinList, optParamsTestList] = buildTestSet('Tests.inp')

N_TESTS = len(pathToTestBinList)

# HABILITA RODAR AS SIMULAÇOES PARA EXTRAÇAO DOS RESULTADOS DE REFERENCIA. CASO ESSES ARQUIVOS JAH EXISTAM DE SIMULAÇOES ANTERIORES,
# MANTENHA-OS NO DIRETORIO APONTADO POR hmOutputPath
RUN_REFERENCE = True

# HABILITA RODAR AS SIMULAÇOES DE TESTE
RUN_TEST = True

# HABILITA EXECUCAO EM PARALELO (requer JobLib instalado)
RUN_PARALLEL = True

# SETA NUMERO MAXIMO DE THREADS PARA EXECUCAO EM PARALELO. NA FORMA COMO ESTA IMPLEMENTADO. O MAXIMO DE PARALELISMO DO CODIGO EH 4
NUM_THREADS = 4
